#include <capture.h>


/* this is the callback function used by pcap. which means, whenever pcap receives a packet it calls this function. 
 * let me explain the parameters of pcap_callback now
 * 0) first one is a parameter we just wanted to pass to our function (basically any variable(s) we want to use in 
 *    here from main())
 * 1) second one is the header of the packet we captured, this includes ethernet header, followed by ip header etc.
 * 2) third one is the full packet, i.e. raw packet right out of the wire with its payload
 *
 * so, what i'm doing here is simply adding the packet and packet header to a linked-list, but you can do anything
 * you want this packet. see what i'm doing with the packets i store in the linked-list in the main, you can almost
 * copy-paste that stuff here and it would work just fine.
 */
void pcap_callback (u_char * arg, const struct pcap_pkthdr *pkthdr, const u_char * packet){

  /* just append the packet header and raw packet to the linked-list
   * nothing fancy here, look at main() to learn how to work with the 
   * packet header etc. 
   */
  unsigned int size_of_iphdr= sizeof(ip_header); /* size of the ip header */
  unsigned int size_of_ehdr= sizeof(ethernet_header);  /* size of the ethernet header */
  unsigned int size_of_tcphdr= sizeof(tcp_header);

  tcp_header *tcphr=(tcp_header *)(packet+size_of_ehdr+size_of_iphdr);
  if(!((pkthdr->len-(size_of_ehdr+size_of_iphdr)) < size_of_tcphdr)){
     if(((tcphr->th_flags & 0x12)==0x12) || ((tcphr->th_flags & 0x02)==0x02))
        append_item ((buffer *) arg, pkthdr, packet);
  }

  

}
