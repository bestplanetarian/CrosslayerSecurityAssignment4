#ifndef __TCP_CONNECTION_H
#define __TCP_CONNECTION_H

#include <list.h>
#include <pcap.h>
#include <stdlib.h>
#include <arpa/inet.h>



#endif
